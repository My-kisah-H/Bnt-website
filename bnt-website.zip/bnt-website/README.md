# Website Yayasan Bhakti Nusa Tenggara (BNT)

Frontend statis (HTML + CSS + JavaScript murni, tanpa build tool).

```
bnt-website/
├── index.html              # kerangka, template halaman, SEO meta
├── assets/
│   ├── css/styles.css      # desain: token warna, komponen, animasi, responsif
│   ├── js/script.js        # CONFIG data, router, animasi, galeri, donasi, kontak
│   └── img/logo.png        # logo sementara
└── README.md
```

## Cara menjalankan
Buka `index.html` di browser, atau jalankan server lokal: `python3 -m http.server 8000`.
Navigasi memakai hash (`#/tentang`, `#/program/tanggap-bencana`, dst.), jadi bisa di-hosting statis di mana saja.

## Mengisi data resmi
Semua data ada di blok `CONFIG` di bagian atas `assets/js/script.js`. Kosong = tampil sebagai placeholder.

| Data | Lokasi di CONFIG |
|---|---|
| Nomor WhatsApp (`62812...`), email, alamat, media sosial | `contact` |
| Akta, SK Kemenkumham, NPWP | `legal` |
| Rekening resmi | `banks` |
| Angka statistik (counter) | `stats[].value` |
| Foto hero/program | `photos` (path gambar) |
| Kegiatan (foto/video/artikel) | `activities` |
| Laporan (PDF) | `reports` |
| Ringkasan keuangan | `finance` |

Teks sejarah, visi, dan misi ada di `index.html` (template `tpl-tentang`, ditandai kotak garis putus) menunggu naskah resmi.

## Jalur menuju website dinamis
- `Api.load(resource)` adalah titik sambung: ganti dengan `fetch('/api/programs')`, `/api/activities`, `/api/reports`.
- Bentuk data `programs`, `activities`, `reports` sudah menyerupai tabel database.
- `PaymentGateway.createCheckout()` adalah adaptor payment gateway (isi `CONFIG.payment.provider`).
- Formulir kontak: isi `CONFIG.api.contact` dengan endpoint POST.
- Saran tahap berikut: admin dashboard + CRUD artikel/galeri/program/laporan, database, dan halaman per-URL (SSR/static generation) agar SEO tiap halaman optimal.
